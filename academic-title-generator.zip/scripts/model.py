import torch
from transformers import (
    T5ForConditionalGeneration, 
    T5Tokenizer,
    BartForConditionalGeneration,
    BartTokenizer,
    pipeline
)
import pandas as pd
import numpy as np
from typing import List, Dict, Tuple
import re

class AcademicTitleGenerator:
    def __init__(self, model_name: str = "t5-base", max_length: int = 512):
        """
        Initialize the Academic Title Generator
        
        Args:
            model_name: Name of the pretrained model to use
            max_length: Maximum sequence length for input
        """
        self.model_name = model_name
        self.max_length = max_length
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Load model and tokenizer based on model type
        if "t5" in model_name.lower():
            self.model = T5ForConditionalGeneration.from_pretrained(model_name)
            self.tokenizer = T5Tokenizer.from_pretrained(model_name)
        elif "bart" in model_name.lower():
            self.model = BartForConditionalGeneration.from_pretrained(model_name)
            self.tokenizer = BartTokenizer.from_pretrained(model_name)
        else:
            raise ValueError(f"Unsupported model: {model_name}")
        
        self.model.to(self.device)
        print(f"Model loaded on {self.device}")
    
    def preprocess_abstract(self, abstract: str) -> str:
        """
        Preprocess the abstract text
        
        Args:
            abstract: Raw abstract text
            
        Returns:
            Cleaned abstract text
        """
        # Remove extra whitespace and newlines
        abstract = re.sub(r'\s+', ' ', abstract.strip())
        
        # Remove special characters but keep punctuation
        abstract = re.sub(r'[^\w\s\.\,\;\:\!\?\-$$$$]', '', abstract)
        
        # Add task prefix for T5
        if "t5" in self.model_name.lower():
            abstract = f"summarize: {abstract}"
        
        return abstract
    
    def generate_title(self, abstract: str, num_beams: int = 4, 
                      max_title_length: int = 50, temperature: float = 0.7) -> str:
        """
        Generate a title from an abstract
        
        Args:
            abstract: Paper abstract
            num_beams: Number of beams for beam search
            max_title_length: Maximum length of generated title
            temperature: Sampling temperature
            
        Returns:
            Generated title
        """
        # Preprocess the abstract
        processed_abstract = self.preprocess_abstract(abstract)
        
        # Tokenize input
        inputs = self.tokenizer.encode(
            processed_abstract,
            return_tensors="pt",
            max_length=self.max_length,
            truncation=True,
            padding=True
        ).to(self.device)
        
        # Generate title
        with torch.no_grad():
            outputs = self.model.generate(
                inputs,
                max_length=max_title_length,
                num_beams=num_beams,
                temperature=temperature,
                do_sample=True,
                early_stopping=True,
                pad_token_id=self.tokenizer.pad_token_id,
                eos_token_id=self.tokenizer.eos_token_id
            )
        
        # Decode the generated title
        title = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Post-process title
        title = self.postprocess_title(title)
        
        return title
    
    def postprocess_title(self, title: str) -> str:
        """
        Post-process the generated title
        
        Args:
            title: Raw generated title
            
        Returns:
            Cleaned title
        """
        # Remove task prefix if present
        if title.lower().startswith("summarize:"):
            title = title[10:].strip()
        
        # Capitalize first letter
        title = title.strip()
        if title:
            title = title[0].upper() + title[1:]
        
        # Remove trailing punctuation except period
        title = re.sub(r'[^\w\s\.]$', '', title)
        
        return title
    
    def generate_multiple_titles(self, abstract: str, num_titles: int = 3) -> List[str]:
        """
        Generate multiple title candidates
        
        Args:
            abstract: Paper abstract
            num_titles: Number of titles to generate
            
        Returns:
            List of generated titles
        """
        titles = []
        for i in range(num_titles):
            # Vary parameters for diversity
            temperature = 0.7 + (i * 0.1)
            num_beams = 4 + i
            
            title = self.generate_title(
                abstract, 
                num_beams=num_beams, 
                temperature=temperature
            )
            titles.append(title)
        
        return titles

# Example usage and testing
if __name__ == "__main__":
    # Initialize the generator
    generator = AcademicTitleGenerator("t5-base")
    
    # Sample abstract
    sample_abstract = """
    This paper presents a novel approach to natural language processing using transformer 
    architectures for text summarization. We propose a new attention mechanism that 
    improves the quality of generated summaries by focusing on key semantic elements. 
    Our experiments on benchmark datasets show significant improvements over existing 
    methods, achieving state-of-the-art results on ROUGE metrics. The proposed method 
    demonstrates superior performance in capturing important information while maintaining 
    coherence and readability.
    """
    
    # Generate titles
    print("Generated Titles:")
    titles = generator.generate_multiple_titles(sample_abstract, num_titles=3)
    for i, title in enumerate(titles, 1):
        print(f"{i}. {title}")
