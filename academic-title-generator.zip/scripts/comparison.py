import pandas as pd
import numpy as np
from model import AcademicTitleGenerator
from evaluation import TitleGenerationEvaluator
import time
from typing import List, Dict
import matplotlib.pyplot as plt
import seaborn as sns

class BaselineTitleGenerator:
    """
    Simple baseline title generator using extractive methods
    """
    def __init__(self):
        self.name = "Extractive Baseline"
    
    def generate_title(self, abstract: str) -> str:
        """
        Generate title by extracting key phrases from abstract
        """
        # Simple extractive approach: take first sentence and shorten it
        sentences = abstract.split('.')
        if sentences:
            first_sentence = sentences[0].strip()
            # Remove common starting phrases
            prefixes_to_remove = [
                "this paper", "this study", "this work", "this research",
                "we present", "we propose", "we introduce", "we develop"
            ]
            
            title = first_sentence.lower()
            for prefix in prefixes_to_remove:
                if title.startswith(prefix):
                    title = title[len(prefix):].strip()
                    break
            
            # Capitalize and limit length
            title = title.capitalize()
            words = title.split()[:8]  # Limit to 8 words
            return ' '.join(words)
        
        return "Untitled Research Paper"

class KeywordBasedGenerator:
    """
    Keyword-based title generator
    """
    def __init__(self):
        self.name = "Keyword-Based Generator"
        # Common academic keywords
        self.academic_keywords = [
            'novel', 'approach', 'method', 'algorithm', 'framework',
            'analysis', 'study', 'investigation', 'evaluation', 'system',
            'model', 'technique', 'strategy', 'solution', 'application'
        ]
    
    def extract_keywords(self, text: str) -> List[str]:
        """
        Extract important keywords from text
        """
        words = text.lower().split()
        keywords = []
        
        # Look for academic keywords
        for word in words:
            clean_word = word.strip('.,!?;:()[]{}')
            if (len(clean_word) > 4 and 
                clean_word not in ['paper', 'research', 'study', 'work'] and
                clean_word.isalpha()):
                keywords.append(clean_word)
        
        return keywords[:5]  # Return top 5 keywords
    
    def generate_title(self, abstract: str) -> str:
        """
        Generate title based on extracted keywords
        """
        keywords = self.extract_keywords(abstract)
        
        if len(keywords) >= 2:
            # Create title using keywords
            title_templates = [
                f"{keywords[0].capitalize()} {keywords[1].capitalize()}: A Novel Approach",
                f"Advanced {keywords[0].capitalize()} for {keywords[1].capitalize()}",
                f"{keywords[0].capitalize()}-Based {keywords[1].capitalize()} Method",
                f"Novel {keywords[0].capitalize()} and {keywords[1].capitalize()} Framework"
            ]
            return title_templates[0]
        else:
            return "Advanced Research Method and Analysis"

class ModelComparison:
    """
    Compare different title generation approaches
    """
    def __init__(self):
        self.evaluator = TitleGenerationEvaluator()
        
        # Initialize models
        self.models = {
            'T5-Base (Proposed)': AcademicTitleGenerator("t5-base"),
            'Extractive Baseline': BaselineTitleGenerator(),
            'Keyword-Based': KeywordBasedGenerator()
        }
    
    def run_comparison(self, test_abstracts: List[str], test_titles: List[str]) -> Dict:
        """
        Run comprehensive comparison of all models
        """
        results = {}
        
        print("Running model comparison...")
        print("=" * 50)
        
        for model_name, model in self.models.items():
            print(f"\nEvaluating {model_name}...")
            
            start_time = time.time()
            
            # Generate titles
            generated_titles = []
            for abstract in test_abstracts:
                title = model.generate_title(abstract)
                generated_titles.append(title)
            
            generation_time = time.time() - start_time
            
            # Calculate metrics
            rouge_scores = self.evaluator.calculate_rouge_scores(generated_titles, test_titles)
            bleu_scores = self.evaluator.calculate_bleu_scores(generated_titles, test_titles)
            length_stats = self.evaluator.calculate_length_statistics(generated_titles, test_titles)
            
            results[model_name] = {
                'rouge_scores': rouge_scores,
                'bleu_scores': bleu_scores,
                'length_statistics': length_stats,
                'generated_titles': generated_titles,
                'generation_time': generation_time,
                'avg_time_per_title': generation_time / len(test_abstracts)
            }
            
            print(f"ROUGE-1: {rouge_scores['rouge1']['mean']:.4f}")
            print(f"ROUGE-2: {rouge_scores['rouge2']['mean']:.4f}")
            print(f"ROUGE-L: {rouge_scores['rougeL']['mean']:.4f}")
            print(f"BLEU: {bleu_scores['mean']:.4f}")
            print(f"Avg time per title: {results[model_name]['avg_time_per_title']:.2f}s")
        
        return results
    
    def create_comparison_plots(self, results: Dict, save_path: str = "model_comparison.png"):
        """
        Create comparison visualization
        """
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        model_names = list(results.keys())
        
        # ROUGE scores comparison
        rouge1_scores = [results[model]['rouge_scores']['rouge1']['mean'] for model in model_names]
        rouge2_scores = [results[model]['rouge_scores']['rouge2']['mean'] for model in model_names]
        rougeL_scores = [results[model]['rouge_scores']['rougeL']['mean'] for model in model_names]
        
        x = np.arange(len(model_names))
        width = 0.25
        
        axes[0, 0].bar(x - width, rouge1_scores, width, label='ROUGE-1', alpha=0.8)
        axes[0, 0].bar(x, rouge2_scores, width, label='ROUGE-2', alpha=0.8)
        axes[0, 0].bar(x + width, rougeL_scores, width, label='ROUGE-L', alpha=0.8)
        axes[0, 0].set_xlabel('Models')
        axes[0, 0].set_ylabel('ROUGE Score')
        axes[0, 0].set_title('ROUGE Scores Comparison')
        axes[0, 0].set_xticks(x)
        axes[0, 0].set_xticklabels(model_names, rotation=45, ha='right')
        axes[0, 0].legend()
        axes[0, 0].grid(True, alpha=0.3)
        
        # BLEU scores comparison
        bleu_scores = [results[model]['bleu_scores']['mean'] for model in model_names]
        bars = axes[0, 1].bar(model_names, bleu_scores, color=['#1f77b4', '#ff7f0e', '#2ca02c'])
        axes[0, 1].set_xlabel('Models')
        axes[0, 1].set_ylabel('BLEU Score')
        axes[0, 1].set_title('BLEU Scores Comparison')
        axes[0, 1].tick_params(axis='x', rotation=45)
        axes[0, 1].grid(True, alpha=0.3)
        
        # Add value labels on bars
        for bar, score in zip(bars, bleu_scores):
            axes[0, 1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                           f'{score:.3f}', ha='center', va='bottom')
        
        # Generation time comparison
        gen_times = [results[model]['avg_time_per_title'] for model in model_names]
        bars = axes[1, 0].bar(model_names, gen_times, color=['#d62728', '#9467bd', '#8c564b'])
        axes[1, 0].set_xlabel('Models')
        axes[1, 0].set_ylabel('Average Time per Title (seconds)')
        axes[1, 0].set_title('Generation Speed Comparison')
        axes[1, 0].tick_params(axis='x', rotation=45)
        axes[1, 0].grid(True, alpha=0.3)
        
        # Add value labels on bars
        for bar, time_val in zip(bars, gen_times):
            axes[1, 0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                           f'{time_val:.2f}s', ha='center', va='bottom')
        
        # Overall performance radar chart
        from math import pi
        
        categories = ['ROUGE-1', 'ROUGE-2', 'ROUGE-L', 'BLEU']
        N = len(categories)
        
        angles = [n / float(N) * 2 * pi for n in range(N)]
        angles += angles[:1]  # Complete the circle
        
        ax = plt.subplot(2, 2, 4, projection='polar')
        
        colors = ['#1f77b4', '#ff7f0e', '#2ca02c']
        for i, model_name in enumerate(model_names):
            values = [
                results[model_name]['rouge_scores']['rouge1']['mean'],
                results[model_name]['rouge_scores']['rouge2']['mean'],
                results[model_name]['rouge_scores']['rougeL']['mean'],
                results[model_name]['bleu_scores']['mean']
            ]
            values += values[:1]  # Complete the circle
            
            ax.plot(angles, values, 'o-', linewidth=2, label=model_name, color=colors[i])
            ax.fill(angles, values, alpha=0.25, color=colors[i])
        
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(categories)
        ax.set_ylim(0, 1)
        ax.set_title('Overall Performance Comparison', y=1.08)
        ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0))
        ax.grid(True)
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.show()
        
        print(f"Comparison plots saved to {save_path}")
    
    def generate_comparison_report(self, results: Dict, save_path: str = "comparison_report.txt"):
        """
        Generate detailed comparison report
        """
        report = []
        report.append("ACADEMIC TITLE GENERATION - MODEL COMPARISON REPORT")
        report.append("=" * 60)
        report.append("")
        
        # Summary table
        report.append("PERFORMANCE SUMMARY")
        report.append("-" * 30)
        report.append(f"{'Model':<25} {'ROUGE-1':<10} {'ROUGE-2':<10} {'ROUGE-L':<10} {'BLEU':<10} {'Time(s)':<10}")
        report.append("-" * 75)
        
        for model_name, result in results.items():
            rouge1 = result['rouge_scores']['rouge1']['mean']
            rouge2 = result['rouge_scores']['rouge2']['mean']
            rougeL = result['rouge_scores']['rougeL']['mean']
            bleu = result['bleu_scores']['mean']
            time_per_title = result['avg_time_per_title']
            
            report.append(f"{model_name:<25} {rouge1:<10.4f} {rouge2:<10.4f} {rougeL:<10.4f} {bleu:<10.4f} {time_per_title:<10.2f}")
        
        report.append("")
        report.append("DETAILED ANALYSIS")
        report.append("-" * 20)
        
        # Find best performing model
        best_rouge1 = max(results.keys(), key=lambda x: results[x]['rouge_scores']['rouge1']['mean'])
        best_bleu = max(results.keys(), key=lambda x: results[x]['bleu_scores']['mean'])
        fastest = min(results.keys(), key=lambda x: results[x]['avg_time_per_title'])
        
        report.append(f"Best ROUGE-1 Score: {best_rouge1}")
        report.append(f"Best BLEU Score: {best_bleu}")
        report.append(f"Fastest Generation: {fastest}")
        report.append("")
        
        # Sample comparisons
        report.append("SAMPLE TITLE COMPARISONS")
        report.append("-" * 30)
        
        for i in range(min(3, len(results[list(results.keys())[0]]['generated_titles']))):
            report.append(f"Example {i+1}:")
            for model_name in results.keys():
                title = results[model_name]['generated_titles'][i]
                report.append(f"  {model_name}: {title}")
            report.append("")
        
        # Save report
        with open(save_path, 'w') as f:
            f.write('\n'.join(report))
        
        print(f"Comparison report saved to {save_path}")
        
        # Print summary to console
        print("\n" + "\n".join(report[:20]))

# Example usage
if __name__ == "__main__":
    # Sample test data
    test_data = {
        'abstracts': [
            "This paper introduces a novel deep learning architecture for computer vision tasks. We propose a new convolutional neural network design that achieves superior performance on image classification benchmarks. Our method combines attention mechanisms with residual connections to improve feature extraction and representation learning. Experimental results demonstrate significant improvements over state-of-the-art methods on multiple datasets.",
            
            "We present a comprehensive study on natural language processing using transformer models. Our research focuses on improving text generation quality through advanced attention mechanisms and training strategies. The proposed approach shows remarkable performance in various NLP tasks including summarization, translation, and question answering. Experimental validation confirms the effectiveness of our method.",
            
            "This work investigates the application of reinforcement learning in robotics. We develop a new algorithm for robot navigation in complex environments using deep Q-learning and policy gradient methods. The proposed system demonstrates robust performance in both simulation and real-world scenarios. Our approach significantly outperforms existing navigation algorithms in terms of success rate and efficiency.",
            
            "We propose a novel machine learning framework for medical image analysis. The system combines convolutional neural networks with attention mechanisms for accurate disease detection and classification. Our method achieves state-of-the-art performance on multiple medical imaging datasets. The proposed approach shows great potential for clinical applications and automated diagnosis.",
            
            "This paper presents an innovative approach to time series forecasting using hybrid neural networks. We combine LSTM networks with transformer architectures to capture both short-term and long-term dependencies in temporal data. Experimental results on financial and weather datasets demonstrate superior forecasting accuracy compared to traditional methods."
        ],
        'titles': [
            "Novel Deep Learning Architecture for Enhanced Computer Vision",
            "Transformer-Based Natural Language Processing: Advanced Text Generation",
            "Reinforcement Learning Algorithm for Robust Robot Navigation",
            "Machine Learning Framework for Automated Medical Image Analysis",
            "Hybrid Neural Networks for Advanced Time Series Forecasting"
        ]
    }
    
    # Run comparison
    comparison = ModelComparison()
    results = comparison.run_comparison(test_data['abstracts'], test_data['titles'])
    
    # Generate visualizations and report
    comparison.create_comparison_plots(results)
    comparison.generate_comparison_report(results)
    
    print("\nComparison completed successfully!")
