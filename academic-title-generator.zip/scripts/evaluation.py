import numpy as np
import pandas as pd
from rouge_score import rouge_scorer
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from nltk.tokenize import word_tokenize
import nltk
from model import AcademicTitleGenerator
from typing import List, Dict
import matplotlib.pyplot as plt
import seaborn as sns

# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

class TitleGenerationEvaluator:
    def __init__(self):
        self.rouge_scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
        self.smoothing_function = SmoothingFunction().method1
    
    def calculate_rouge_scores(self, generated_titles: List[str], reference_titles: List[str]) -> Dict:
        """
        Calculate ROUGE scores for generated titles
        """
        rouge1_scores = []
        rouge2_scores = []
        rougeL_scores = []
        
        for gen_title, ref_title in zip(generated_titles, reference_titles):
            scores = self.rouge_scorer.score(ref_title, gen_title)
            rouge1_scores.append(scores['rouge1'].fmeasure)
            rouge2_scores.append(scores['rouge2'].fmeasure)
            rougeL_scores.append(scores['rougeL'].fmeasure)
        
        return {
            'rouge1': {
                'mean': np.mean(rouge1_scores),
                'std': np.std(rouge1_scores),
                'scores': rouge1_scores
            },
            'rouge2': {
                'mean': np.mean(rouge2_scores),
                'std': np.std(rouge2_scores),
                'scores': rouge2_scores
            },
            'rougeL': {
                'mean': np.mean(rougeL_scores),
                'std': np.std(rougeL_scores),
                'scores': rougeL_scores
            }
        }
    
    def calculate_bleu_scores(self, generated_titles: List[str], reference_titles: List[str]) -> Dict:
        """
        Calculate BLEU scores for generated titles
        """
        bleu_scores = []
        
        for gen_title, ref_title in zip(generated_titles, reference_titles):
            # Tokenize titles
            gen_tokens = word_tokenize(gen_title.lower())
            ref_tokens = [word_tokenize(ref_title.lower())]
            
            # Calculate BLEU score
            bleu_score = sentence_bleu(ref_tokens, gen_tokens, smoothing_function=self.smoothing_function)
            bleu_scores.append(bleu_score)
        
        return {
            'mean': np.mean(bleu_scores),
            'std': np.std(bleu_scores),
            'scores': bleu_scores
        }
    
    def calculate_length_statistics(self, generated_titles: List[str], reference_titles: List[str]) -> Dict:
        """
        Calculate length-based statistics
        """
        gen_lengths = [len(title.split()) for title in generated_titles]
        ref_lengths = [len(title.split()) for title in reference_titles]
        
        return {
            'generated': {
                'mean_length': np.mean(gen_lengths),
                'std_length': np.std(gen_lengths),
                'lengths': gen_lengths
            },
            'reference': {
                'mean_length': np.mean(ref_lengths),
                'std_length': np.std(ref_lengths),
                'lengths': ref_lengths
            }
        }
    
    def evaluate_model(self, model: AcademicTitleGenerator, test_abstracts: List[str], 
                      test_titles: List[str]) -> Dict:
        """
        Comprehensive evaluation of the model
        """
        print("Generating titles for evaluation...")
        generated_titles = []
        
        for abstract in test_abstracts:
            title = model.generate_title(abstract)
            generated_titles.append(title)
        
        print("Calculating evaluation metrics...")
        
        # Calculate ROUGE scores
        rouge_scores = self.calculate_rouge_scores(generated_titles, test_titles)
        
        # Calculate BLEU scores
        bleu_scores = self.calculate_bleu_scores(generated_titles, test_titles)
        
        # Calculate length statistics
        length_stats = self.calculate_length_statistics(generated_titles, test_titles)
        
        results = {
            'rouge_scores': rouge_scores,
            'bleu_scores': bleu_scores,
            'length_statistics': length_stats,
            'generated_titles': generated_titles,
            'reference_titles': test_titles
        }
        
        return results
    
    def print_evaluation_results(self, results: Dict):
        """
        Print formatted evaluation results
        """
        print("\n" + "="*50)
        print("EVALUATION RESULTS")
        print("="*50)
        
        # ROUGE Scores
        print("\nROUGE Scores:")
        print(f"ROUGE-1: {results['rouge_scores']['rouge1']['mean']:.4f} ± {results['rouge_scores']['rouge1']['std']:.4f}")
        print(f"ROUGE-2: {results['rouge_scores']['rouge2']['mean']:.4f} ± {results['rouge_scores']['rouge2']['std']:.4f}")
        print(f"ROUGE-L: {results['rouge_scores']['rougeL']['mean']:.4f} ± {results['rouge_scores']['rougeL']['std']:.4f}")
        
        # BLEU Scores
        print(f"\nBLEU Score: {results['bleu_scores']['mean']:.4f} ± {results['bleu_scores']['std']:.4f}")
        
        # Length Statistics
        print(f"\nLength Statistics:")
        print(f"Generated titles - Mean: {results['length_statistics']['generated']['mean_length']:.2f} words")
        print(f"Reference titles - Mean: {results['length_statistics']['reference']['mean_length']:.2f} words")
        
        # Sample comparisons
        print(f"\nSample Title Comparisons:")
        print("-" * 50)
        for i in range(min(3, len(results['generated_titles']))):
            print(f"Generated: {results['generated_titles'][i]}")
            print(f"Reference: {results['reference_titles'][i]}")
            print("-" * 30)
    
    def create_evaluation_plots(self, results: Dict, save_path: str = "evaluation_plots.png"):
        """
        Create visualization plots for evaluation results
        """
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        # ROUGE scores distribution
        rouge_data = [
            results['rouge_scores']['rouge1']['scores'],
            results['rouge_scores']['rouge2']['scores'],
            results['rouge_scores']['rougeL']['scores']
        ]
        axes[0, 0].boxplot(rouge_data, labels=['ROUGE-1', 'ROUGE-2', 'ROUGE-L'])
        axes[0, 0].set_title('ROUGE Scores Distribution')
        axes[0, 0].set_ylabel('Score')
        
        # BLEU scores histogram
        axes[0, 1].hist(results['bleu_scores']['scores'], bins=20, alpha=0.7, color='skyblue')
        axes[0, 1].set_title('BLEU Scores Distribution')
        axes[0, 1].set_xlabel('BLEU Score')
        axes[0, 1].set_ylabel('Frequency')
        
        # Length comparison
        gen_lengths = results['length_statistics']['generated']['lengths']
        ref_lengths = results['length_statistics']['reference']['lengths']
        axes[1, 0].scatter(ref_lengths, gen_lengths, alpha=0.6)
        axes[1, 0].plot([0, max(max(ref_lengths), max(gen_lengths))], 
                       [0, max(max(ref_lengths), max(gen_lengths))], 'r--')
        axes[1, 0].set_xlabel('Reference Title Length (words)')
        axes[1, 0].set_ylabel('Generated Title Length (words)')
        axes[1, 0].set_title('Title Length Comparison')
        
        # Score correlation
        rouge1_scores = results['rouge_scores']['rouge1']['scores']
        bleu_scores = results['bleu_scores']['scores']
        axes[1, 1].scatter(rouge1_scores, bleu_scores, alpha=0.6)
        axes[1, 1].set_xlabel('ROUGE-1 Score')
        axes[1, 1].set_ylabel('BLEU Score')
        axes[1, 1].set_title('ROUGE-1 vs BLEU Score Correlation')
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.show()
        
        print(f"Evaluation plots saved to {save_path}")

# Example evaluation script
if __name__ == "__main__":
    # Sample test data
    test_data = {
        'abstracts': [
            "This paper introduces a novel deep learning architecture for computer vision tasks. We propose a new convolutional neural network design that achieves superior performance on image classification benchmarks. Our method combines attention mechanisms with residual connections to improve feature extraction and representation learning.",
            "We present a comprehensive study on natural language processing using transformer models. Our research focuses on improving text generation quality through advanced attention mechanisms and training strategies. Experimental results demonstrate significant improvements over baseline methods.",
            "This work investigates the application of reinforcement learning in robotics. We develop a new algorithm for robot navigation in complex environments. The proposed method shows robust performance in both simulation and real-world scenarios."
        ],
        'titles': [
            "Novel Deep Learning Architecture for Enhanced Computer Vision",
            "Transformer-Based Natural Language Processing: Advanced Text Generation",
            "Reinforcement Learning Algorithm for Robust Robot Navigation"
        ]
    }
    
    # Initialize model and evaluator
    model = AcademicTitleGenerator("t5-base")
    evaluator = TitleGenerationEvaluator()
    
    # Run evaluation
    results = evaluator.evaluate_model(model, test_data['abstracts'], test_data['titles'])
    
    # Print results
    evaluator.print_evaluation_results(results)
    
    # Create plots
    evaluator.create_evaluation_plots(results)
