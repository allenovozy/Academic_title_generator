import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from transformers import (
    T5ForConditionalGeneration,
    T5Tokenizer,
    AdamW,
    get_linear_schedule_with_warmup
)
from sklearn.model_selection import train_test_split
import numpy as np
from tqdm import tqdm
import json
import os

class PaperDataset(Dataset):
    def __init__(self, abstracts, titles, tokenizer, max_length=512, max_target_length=50):
        self.abstracts = abstracts
        self.titles = titles
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.max_target_length = max_target_length
    
    def __len__(self):
        return len(self.abstracts)
    
    def __getitem__(self, idx):
        abstract = str(self.abstracts[idx])
        title = str(self.titles[idx])
        
        # Add task prefix for T5
        abstract = f"summarize: {abstract}"
        
        # Tokenize inputs
        source = self.tokenizer.encode_plus(
            abstract,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        target = self.tokenizer.encode_plus(
            title,
            max_length=self.max_target_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        return {
            'input_ids': source['input_ids'].flatten(),
            'attention_mask': source['attention_mask'].flatten(),
            'labels': target['input_ids'].flatten()
        }

class TitleGeneratorTrainer:
    def __init__(self, model_name="t5-base", learning_rate=5e-5):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model_name = model_name
        self.learning_rate = learning_rate
        
        # Load model and tokenizer
        self.tokenizer = T5Tokenizer.from_pretrained(model_name)
        self.model = T5ForConditionalGeneration.from_pretrained(model_name)
        self.model.to(self.device)
        
    def prepare_data(self, data_path=None, sample_data=None):
        """
        Prepare training data from CSV file or sample data
        """
        if sample_data is not None:
            df = pd.DataFrame(sample_data)
        elif data_path and os.path.exists(data_path):
            df = pd.read_csv(data_path)
        else:
            # Create sample data for demonstration
            sample_data = {
                'abstract': [
                    "This paper presents a novel machine learning approach for image classification using convolutional neural networks. We achieve state-of-the-art results on benchmark datasets.",
                    "We propose a new natural language processing method for sentiment analysis using transformer models. Our approach outperforms existing baselines on multiple datasets.",
                    "This study investigates the effectiveness of deep learning techniques for medical image analysis. We develop a robust framework for disease detection.",
                    "We introduce a novel reinforcement learning algorithm for autonomous vehicle navigation. The proposed method shows superior performance in simulation environments.",
                    "This paper explores the application of graph neural networks for social network analysis. We demonstrate improved accuracy in link prediction tasks."
                ],
                'title': [
                    "Novel CNN Approach for Advanced Image Classification",
                    "Transformer-Based Sentiment Analysis: A New NLP Method",
                    "Deep Learning Framework for Medical Image Disease Detection",
                    "Reinforcement Learning Algorithm for Autonomous Vehicle Navigation",
                    "Graph Neural Networks for Enhanced Social Network Analysis"
                ]
            }
            df = pd.DataFrame(sample_data)
        
        # Split data
        train_abstracts, val_abstracts, train_titles, val_titles = train_test_split(
            df['abstract'].tolist(),
            df['title'].tolist(),
            test_size=0.2,
            random_state=42
        )
        
        return train_abstracts, val_abstracts, train_titles, val_titles
    
    def train(self, train_abstracts, train_titles, val_abstracts, val_titles, 
              epochs=3, batch_size=4, save_path="./fine_tuned_model"):
        """
        Train the model
        """
        # Create datasets
        train_dataset = PaperDataset(train_abstracts, train_titles, self.tokenizer)
        val_dataset = PaperDataset(val_abstracts, val_titles, self.tokenizer)
        
        # Create data loaders
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size)
        
        # Setup optimizer and scheduler
        optimizer = AdamW(self.model.parameters(), lr=self.learning_rate)
        total_steps = len(train_loader) * epochs
        scheduler = get_linear_schedule_with_warmup(
            optimizer,
            num_warmup_steps=0,
            num_training_steps=total_steps
        )
        
        # Training loop
        self.model.train()
        for epoch in range(epochs):
            total_loss = 0
            progress_bar = tqdm(train_loader, desc=f'Epoch {epoch+1}/{epochs}')
            
            for batch in progress_bar:
                optimizer.zero_grad()
                
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch['labels'].to(self.device)
                
                outputs = self.model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    labels=labels
                )
                
                loss = outputs.loss
                loss.backward()
                optimizer.step()
                scheduler.step()
                
                total_loss += loss.item()
                progress_bar.set_postfix({'loss': loss.item()})
            
            avg_loss = total_loss / len(train_loader)
            print(f"Epoch {epoch+1} - Average Loss: {avg_loss:.4f}")
            
            # Validation
            val_loss = self.validate(val_loader)
            print(f"Validation Loss: {val_loss:.4f}")
        
        # Save the model
        os.makedirs(save_path, exist_ok=True)
        self.model.save_pretrained(save_path)
        self.tokenizer.save_pretrained(save_path)
        print(f"Model saved to {save_path}")
    
    def validate(self, val_loader):
        """
        Validate the model
        """
        self.model.eval()
        total_loss = 0
        
        with torch.no_grad():
            for batch in val_loader:
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch['labels'].to(self.device)
                
                outputs = self.model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    labels=labels
                )
                
                total_loss += outputs.loss.item()
        
        self.model.train()
        return total_loss / len(val_loader)

# Training script
if __name__ == "__main__":
    trainer = TitleGeneratorTrainer()
    
    # Prepare data
    train_abstracts, val_abstracts, train_titles, val_titles = trainer.prepare_data()
    
    # Train the model
    trainer.train(train_abstracts, train_titles, val_abstracts, val_titles)
    
    print("Training completed!")
