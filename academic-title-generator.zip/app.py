from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import os
import logging
from model import AcademicTitleGenerator
import traceback

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize the model
try:
    model = AcademicTitleGenerator("t5-base")
    logger.info("Model loaded successfully")
except Exception as e:
    logger.error(f"Error loading model: {str(e)}")
    model = None

@app.route('/')
def home():
    """
    Home page with API documentation
    """
    return render_template('index.html')

@app.route('/health', methods=['GET'])
def health_check():
    """
    Health check endpoint
    """
    return jsonify({
        'status': 'healthy',
        'model_loaded': model is not None
    })

@app.route('/generate-title', methods=['POST'])
def generate_title():
    """
    Generate a single title from an abstract
    """
    try:
        if model is None:
            return jsonify({
                'error': 'Model not loaded',
                'success': False
            }), 500
        
        data = request.get_json()
        
        if not data or 'abstract' not in data:
            return jsonify({
                'error': 'Abstract is required',
                'success': False
            }), 400
        
        abstract = data['abstract']
        
        if not abstract.strip():
            return jsonify({
                'error': 'Abstract cannot be empty',
                'success': False
            }), 400
        
        # Optional parameters
        num_beams = data.get('num_beams', 4)
        max_length = data.get('max_length', 50)
        temperature = data.get('temperature', 0.7)
        
        # Generate title
        title = model.generate_title(
            abstract,
            num_beams=num_beams,
            max_title_length=max_length,
            temperature=temperature
        )
        
        return jsonify({
            'title': title,
            'success': True,
            'parameters': {
                'num_beams': num_beams,
                'max_length': max_length,
                'temperature': temperature
            }
        })
    
    except Exception as e:
        logger.error(f"Error generating title: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'error': f'Internal server error: {str(e)}',
            'success': False
        }), 500

@app.route('/generate-multiple-titles', methods=['POST'])
def generate_multiple_titles():
    """
    Generate multiple title candidates from an abstract
    """
    try:
        if model is None:
            return jsonify({
                'error': 'Model not loaded',
                'success': False
            }), 500
        
        data = request.get_json()
        
        if not data or 'abstract' not in data:
            return jsonify({
                'error': 'Abstract is required',
                'success': False
            }), 400
        
        abstract = data['abstract']
        num_titles = data.get('num_titles', 3)
        
        if not abstract.strip():
            return jsonify({
                'error': 'Abstract cannot be empty',
                'success': False
            }), 400
        
        if num_titles < 1 or num_titles > 10:
            return jsonify({
                'error': 'Number of titles must be between 1 and 10',
                'success': False
            }), 400
        
        # Generate multiple titles
        titles = model.generate_multiple_titles(abstract, num_titles=num_titles)
        
        return jsonify({
            'titles': titles,
            'success': True,
            'count': len(titles)
        })
    
    except Exception as e:
        logger.error(f"Error generating multiple titles: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'error': f'Internal server error: {str(e)}',
            'success': False
        }), 500

@app.route('/batch-generate', methods=['POST'])
def batch_generate():
    """
    Generate titles for multiple abstracts
    """
    try:
        if model is None:
            return jsonify({
                'error': 'Model not loaded',
                'success': False
            }), 500
        
        data = request.get_json()
        
        if not data or 'abstracts' not in data:
            return jsonify({
                'error': 'Abstracts list is required',
                'success': False
            }), 400
        
        abstracts = data['abstracts']
        
        if not isinstance(abstracts, list):
            return jsonify({
                'error': 'Abstracts must be a list',
                'success': False
            }), 400
        
        if len(abstracts) > 50:
            return jsonify({
                'error': 'Maximum 50 abstracts allowed per batch',
                'success': False
            }), 400
        
        # Generate titles for all abstracts
        results = []
        for i, abstract in enumerate(abstracts):
            try:
                title = model.generate_title(abstract)
                results.append({
                    'index': i,
                    'title': title,
                    'success': True
                })
            except Exception as e:
                results.append({
                    'index': i,
                    'error': str(e),
                    'success': False
                })
        
        return jsonify({
            'results': results,
            'success': True,
            'total_processed': len(results)
        })
    
    except Exception as e:
        logger.error(f"Error in batch generation: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'error': f'Internal server error: {str(e)}',
            'success': False
        }), 500

@app.errorhandler(404)
def not_found(error):
    return jsonify({
        'error': 'Endpoint not found',
        'success': False
    }), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        'error': 'Internal server error',
        'success': False
    }), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('DEBUG', 'False').lower() == 'true'
    
    app.run(host='0.0.0.0', port=port, debug=debug)
